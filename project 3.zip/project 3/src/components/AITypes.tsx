import React from 'react';
import { Mic, MessageSquare, CheckCircle, Play } from 'lucide-react';
import VoiceAIPopup from './VoiceAIPopup';
import ChatbotPopup from './ChatbotPopup';

// Declare the vapi-widget custom element for TypeScript
declare global {
  namespace JSX {
    interface IntrinsicElements {
      'vapi-widget': any;
    }
  }
}

const AITypes = () => {
  const [isVoiceAIOpen, setIsVoiceAIOpen] = React.useState(false);
  const [isChatbotOpen, setIsChatbotOpen] = React.useState(false);

  return (
    <>
    <section className="py-24 bg-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            KI-Installationsservice
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Wir installieren und konfigurieren die perfekte KI-Lösung für Ihr Unternehmen
          </p>
        </div>

        {/* AI Types Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Voice AI */}
          <div className="bg-slate-900/80 backdrop-blur-sm rounded-3xl p-8 border border-slate-700 hover:border-slate-600 shadow-lg hover:shadow-2xl transition-all duration-300">
            <div className="flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl mb-6 mx-auto">
              <Mic className="w-8 h-8 text-white" />
            </div>
            
            <h3 className="text-3xl font-bold text-white mb-6 text-center">
              Voice AI
            </h3>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-gray-300 font-medium">Installation & Konfiguration der Voice AI</span>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-gray-300 font-medium">Integration in Ihre Telefonsysteme</span>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-gray-300 font-medium">Anpassung an Ihre Geschäftsprozesse</span>
              </div>
            </div>

            <button 
              onClick={() => setIsVoiceAIOpen(true)}
              className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 text-white px-6 py-4 rounded-full font-semibold text-lg hover:shadow-xl hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-3"
            >
              <Play className="w-5 h-5" />
              <span>Voice AI testen</span>
            </button>
          </div>

          {/* Chatbot */}
          <div className="bg-slate-900/80 backdrop-blur-sm rounded-3xl p-8 border border-slate-700 hover:border-slate-600 shadow-lg hover:shadow-2xl transition-all duration-300">
            <div className="flex items-center justify-center w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl mb-6 mx-auto">
              <MessageSquare className="w-8 h-8 text-white" />
            </div>
            
            <h3 className="text-3xl font-bold text-white mb-6 text-center">
              Chatbot
            </h3>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-gray-300 font-medium">Installation auf Website & Social Media</span>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-gray-300 font-medium">Individuelle Gesprächsflows & Antworten</span>
              </div>
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-gray-300 font-medium">Training & Wartung inklusive</span>
              </div>
            </div>

            <button 
              onClick={() => setIsChatbotOpen(true)}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-4 rounded-full font-semibold text-lg hover:shadow-xl hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-3"
            >
              <MessageSquare className="w-5 h-5" />
              <span>Chatbot testen</span>
            </button>
          </div>
        </div>
      </div>
    </section>
    
    <VoiceAIPopup 
      isOpen={isVoiceAIOpen} 
      onClose={() => setIsVoiceAIOpen(false)} 
    />
    <ChatbotPopup 
      isOpen={isChatbotOpen} 
      onClose={() => setIsChatbotOpen(false)} 
    />
    </>
  );
};

export default AITypes;