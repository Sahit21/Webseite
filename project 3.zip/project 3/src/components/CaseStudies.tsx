import React from 'react';
import { ArrowRight, TrendingUp, Clock, Users } from 'lucide-react';

const CaseStudies = () => {
  const cases = [
    {
      company: "TechStart GmbH",
      industry: "Software-Entwicklung",
      challenge: "Überlastete Telefonzentrale und verpasste Kundenanfragen",
      solution: "Voice AI Installation mit CRM-Integration",
      results: [
        { metric: "95%", label: "weniger verpasste Anrufe" },
        { metric: "60%", label: "Zeitersparnis im Support" },
        { metric: "40%", label: "mehr qualifizierte Leads" }
      ],
      image: "https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      testimonial: "Die Voice AI hat unsere Kundenbetreuung revolutioniert. Wir verpassen keine Anfrage mehr."
    },
    {
      company: "MedPraxis Dr. Schmidt",
      industry: "Gesundheitswesen",
      challenge: "Terminbuchungen außerhalb der Sprechzeiten nicht möglich",
      solution: "Chatbot Installation mit Terminkalender-Integration",
      results: [
        { metric: "24/7", label: "Terminbuchung verfügbar" },
        { metric: "80%", label: "weniger Telefonanrufe" },
        { metric: "50%", label: "mehr Online-Termine" }
      ],
      image: "https://images.pexels.com/photos/4173251/pexels-photo-4173251.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      testimonial: "Patienten können jetzt rund um die Uhr Termine buchen. Das entlastet unser Team enorm."
    },
    {
      company: "AutoHaus Müller",
      industry: "Automobilhandel",
      challenge: "Ineffiziente Lead-Qualifizierung und Follow-up Prozesse",
      solution: "Voice AI + Chatbot mit automatischen Nachfass-Prozessen",
      results: [
        { metric: "70%", label: "bessere Lead-Qualität" },
        { metric: "3x", label: "mehr Probefahrten" },
        { metric: "45%", label: "höhere Conversion-Rate" }
      ],
      image: "https://images.pexels.com/photos/164634/pexels-photo-164634.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      testimonial: "Die KI qualifiziert Interessenten perfekt. Wir sprechen nur noch mit kaufbereiten Kunden."
    }
  ];

  return (
    <section className="py-24 bg-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Erfolgreiche KI-Installationen
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Echte Ergebnisse von Unternehmen, die auf unsere KI-Lösungen vertrauen
          </p>
        </div>

        {/* Case Studies */}
        <div className="space-y-16">
          {cases.map((caseStudy, index) => (
            <div
              key={index}
              className={`flex flex-col ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} items-center gap-12`}
            >
              {/* Image */}
              <div className="lg:w-1/2">
                <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                  <img
                    src={caseStudy.image}
                    alt={caseStudy.company}
                    className="w-full h-80 object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent"></div>
                </div>
              </div>

              {/* Content */}
              <div className="lg:w-1/2">
                <div className="bg-slate-900 rounded-3xl p-8 border border-slate-700">
                  <div className="mb-6">
                    <h3 className="text-3xl font-bold text-white mb-2">
                      {caseStudy.company}
                    </h3>
                    <p className="text-blue-400 font-semibold">
                      {caseStudy.industry}
                    </p>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <h4 className="text-lg font-semibold text-white mb-2">Herausforderung</h4>
                      <p className="text-gray-300">{caseStudy.challenge}</p>
                    </div>

                    <div>
                      <h4 className="text-lg font-semibold text-white mb-2">Lösung</h4>
                      <p className="text-gray-300">{caseStudy.solution}</p>
                    </div>

                    {/* Results */}
                    <div>
                      <h4 className="text-lg font-semibold text-white mb-4">Ergebnisse</h4>
                      <div className="grid grid-cols-3 gap-4 mb-6">
                        {caseStudy.results.map((result, resultIndex) => (
                          <div key={resultIndex} className="text-center">
                            <div className="text-2xl font-bold text-blue-400 mb-1">
                              {result.metric}
                            </div>
                            <div className="text-sm text-gray-400">
                              {result.label}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Testimonial */}
                    <div className="bg-slate-800 rounded-xl p-4 border-l-4 border-blue-500">
                      <p className="text-gray-300 italic">
                        "{caseStudy.testimonial}"
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <button className="group bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-full font-semibold text-lg hover:shadow-xl hover:scale-105 transition-all duration-300 flex items-center space-x-3 mx-auto">
            <span>Ihre Erfolgsgeschichte starten</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default CaseStudies;