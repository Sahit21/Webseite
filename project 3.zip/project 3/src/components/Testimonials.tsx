import React from 'react';
import { Star } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: "Sabine Meier",
      role: "Geschäftsführerin",
      text: "Die Installation der Voice AI war reibungslos. Unser Telefonsystem wurde perfekt integriert und die KI klingt wirklich natürlich. Unsere Kunden merken oft gar nicht, dass sie mit einer KI sprechen.",
      rating: 5,
      avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop"
    },
    {
      name: "Markus Schuster",
      role: "IT-Leiter",
      text: "Der Chatbot wurde nahtlos in unsere Website integriert. Die individuelle Anpassung an unsere Geschäftsprozesse war beeindruckend. Alles funktioniert perfekt.",
      rating: 5,
      avatar: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop"
    },
    {
      name: "Thomas Keller",
      role: "Praxisinhaber",
      text: "Die Installation war in wenigen Tagen abgeschlossen. Der Support ist hervorragend und die KI wurde perfekt auf unsere Praxis angepasst. Sehr professioneller Service.",
      rating: 5,
      avatar: "https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop"
    }
  ];

  const logos = [
    { name: "Green", color: "text-green-500" },
    { name: "Tech Co", color: "text-blue-500" },
    { name: "Innovate", color: "text-purple-500" },
    { name: "Green", color: "text-green-500" },
    { name: "Tech Co", color: "text-blue-500" },
    { name: "Innovate", color: "text-purple-500" }
  ];

  return (
    <section className="py-24 bg-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Company Logos */}
        <div className="text-center mb-16">
          <h3 className="text-lg text-gray-400 mb-8">Vertrauen von wachsenden Unternehmen</h3>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
            {logos.map((logo, index) => (
              <div key={index} className="flex items-center space-x-2">
                <div className={`w-8 h-8 ${logo.color}`}>
                  <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                  </svg>
                </div>
                <span className={`font-bold text-lg ${logo.color}`}>{logo.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Erfolgreiche KI-Installationen
          </h2>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
            >
              {/* Stars */}
              <div className="flex space-x-1 mb-6">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>

              {/* Testimonial Text */}
              <p className="text-gray-700 mb-6 leading-relaxed">
                {testimonial.text}
              </p>

              <button className="text-blue-600 font-medium hover:text-blue-700 transition-colors mb-6">
                Read more
              </button>

              {/* Author */}
              <div className="flex items-center space-x-4">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-600">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;