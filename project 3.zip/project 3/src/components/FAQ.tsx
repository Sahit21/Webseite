import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: "Ab wann lohnt sich das?",
      answer: "Sobald du regelmäßig Leads bekommst – ob über Anzeigen, Website oder Empfehlungen. Schon ab wenigen Leads pro Woche sorgt die Automatisierung dafür, dass niemand verloren geht und dein Vertrieb nur noch mit interessanten Kontakten spricht."
    },
    {
      question: "Wie teuer ist die Lösung?",
      answer: "Die Kosten hängen von deinem Setup (CRM-Anbindung, Kalender, Anzahl der Kanäle) ab."
    },
    {
      question: "Wie lange dauert die Umsetzung?",
      answer: "Die Basis-Implementierung ist in wenigen Tagen erledigt. Je nach gewünschtem Umfang (z. B. CRM-Anbindung, individuelle Gesprächsflows, Mehrkanal-Follow-ups) starten die meisten Kunden nach 5-7 Werktagen."
    },
    {
      question: "Über welche Kanäle werden die Leads erreicht?",
      answer: "Unsere KI erreicht Leads über Anrufe, E-Mails, WhatsApp und SMS – so wird jeder Interessent zuverlässig kontaktiert, egal welchen Kanal er bevorzugt."
    }
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-24 bg-slate-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden"
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full px-8 py-6 text-left flex items-center justify-between hover:bg-slate-750 transition-colors"
              >
                <h3 className="text-xl font-semibold text-white pr-4">
                  {faq.question}
                </h3>
                {openIndex === index ? (
                  <ChevronUp className="w-6 h-6 text-gray-400 flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-6 h-6 text-gray-400 flex-shrink-0" />
                )}
              </button>
              
              {openIndex === index && (
                <div className="px-8 pb-6">
                  <p className="text-gray-300 leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;